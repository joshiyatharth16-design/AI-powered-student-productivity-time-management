"""
exceptions.py
-------------
Custom exceptions for the Student Productivity App.
All exceptions extend the built-in Exception class.
"""


class TaskNotFoundError(Exception):
    """Raised when a task_id does not exist in the task list."""
    pass


class TaskAlreadyCompletedError(Exception):
    """Raised when trying to complete or edit an already-completed task."""
    pass


class TimerAlreadyRunningError(Exception):
    """Raised when trying to start a timer while another is already running."""
    pass


class TimerNotRunningError(Exception):
    """Raised when trying to stop a timer that was never started."""
    pass
