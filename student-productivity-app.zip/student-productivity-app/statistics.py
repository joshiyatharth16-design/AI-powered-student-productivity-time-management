"""
statistics.py
-------------
Computes productivity statistics from the current task list.

All methods are pure calculations — no side effects, no file I/O.
"""

from datetime import date, datetime
from task_manager import Task, TaskManager


class Statistics:
    """
    Calculates productivity numbers for display on the Statistics tab.

    Usage:
        stats = Statistics(manager)
        stats.completion_percentage()    # e.g. 66.7
        stats.tasks_completed_today()    # e.g. 2
        stats.total_time_today_seconds() # e.g. 3600
    """

    def __init__(self, task_manager: TaskManager) -> None:
        self._manager = task_manager

    # ------------------------------------------------------------------
    # Core statistics
    # ------------------------------------------------------------------

    def total_tasks(self) -> int:
        """Return the total number of tasks (pending + completed)."""
        return len(self._manager.get_all_tasks())

    def total_completed(self) -> int:
        """Return the number of completed tasks."""
        return len(self._manager.get_completed_tasks())

    def total_pending(self) -> int:
        """Return the number of pending tasks."""
        return len(self._manager.get_pending_tasks())

    def completion_percentage(self) -> float:
        """
        Return the percentage of tasks that are completed.
        Returns 0.0 if there are no tasks (avoids division by zero).
        """
        total = self.total_tasks()
        if total == 0:
            return 0.0
        return round((self.total_completed() / total) * 100, 1)

    # ------------------------------------------------------------------
    # Daily statistics
    # ------------------------------------------------------------------

    def tasks_completed_today(self) -> int:
        """
        Return how many tasks were marked complete today.
        """
        today = date.today()
        count = 0
        for task in self._manager.get_completed_tasks():
            if task.completed_at and task.completed_at.date() == today:
                count += 1
        return count

    def total_time_today_seconds(self) -> int:
        """
        Return the total seconds spent on tasks that were created today.

        Note for beginners:
            We use created_at.date() == today as the proxy for "today's tasks"
            because time_spent_seconds accumulates across sessions and we have
            no per-day breakdown in this simple version.
        """
        today = date.today()
        total = 0
        for task in self._manager.get_all_tasks():
            if task.created_at.date() == today:
                total += task.time_spent_seconds
        return total

    def tasks_with_upcoming_deadlines(self, within_days: int = 2) -> list[Task]:
        """
        Return pending tasks whose deadline is within `within_days` days from today.

        Args:
            within_days: How many days ahead to look (default: 2 = today + tomorrow).
        """
        today = date.today()
        result: list[Task] = []
        for task in self._manager.get_pending_tasks():
            days_left = (task.deadline - today).days
            if 0 <= days_left <= within_days:
                result.append(task)
        return result
