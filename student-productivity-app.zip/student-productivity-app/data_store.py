"""
data_store.py
-------------
Handles reading and writing all task data to a local tasks.json file.
This is the only module that touches the filesystem.
"""

import json
import os
from typing import Any


# Path to the JSON file that stores all tasks.
# You can change this path if needed.
DATA_FILE = "tasks.json"


class DataStore:
    """
    Manages reading and writing task data to a JSON file.

    Usage:
        store = DataStore()
        store.save(tasks_list)
        tasks_list = store.load()
    """

    def __init__(self, file_path: str = DATA_FILE) -> None:
        self.file_path = file_path

    def save(self, tasks: list[dict[str, Any]]) -> None:
        """
        Write the list of task dictionaries to the JSON file.

        Args:
            tasks: A list of task dictionaries (from Task.to_dict()).
        """
        with open(self.file_path, "w", encoding="utf-8") as f:
            json.dump(tasks, f, indent=2, ensure_ascii=False)

    def load(self) -> list[dict[str, Any]]:
        """
        Read task dictionaries from the JSON file.

        Returns:
            A list of task dictionaries, or an empty list if the file
            does not exist or contains invalid JSON.
        """
        if not os.path.exists(self.file_path):
            return []

        try:
            with open(self.file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                # Guard against a file that contains something other than a list
                if not isinstance(data, list):
                    return []
                return data
        except (json.JSONDecodeError, OSError):
            # Corrupted or unreadable file — start fresh rather than crashing
            return []
