# AI-Powered Student Productivity & Time Management App — Implementation Plan

## Top-Level Overview

**Goal:** Build a beginner-friendly, single-user desktop-style web application using Python, Streamlit, and JSON for persistence. Students can manage tasks, track time spent on them, view productivity statistics, and receive simple rule-based AI suggestions on what to work on next.

**Scope:**
- 6 Python modules, 6 classes, ~25 methods
- Data persisted to a local `tasks.json` file — survives restarts and page refreshes
- Timer start time is stored in `tasks.json` so a running timer survives a Streamlit page refresh
- Pending tasks can be edited (title, description, priority, deadline); completed tasks cannot
- No task deletion in this version
- No user login or accounts — single student user
- AI suggestions are rule-based (no ML library)

**Non-Goals:** Multi-user support, authentication, cloud storage, ML/LLM integration, task deletion.

**Project Root:** `C:\Users\uadhy\Documents\student-productivity-app`

---

## Project Folder Structure

```
student-productivity-app/
│
├── app.py                    # Streamlit UI — entry point
├── task_manager.py           # Task class + TaskManager class
├── time_tracker.py           # TimeTracker class
├── statistics.py             # Statistics class
├── ai_suggestions.py         # AISuggestion class
├── data_store.py             # DataStore class (JSON read/write)
├── exceptions.py             # All custom exceptions
│
├── tests/
│   ├── test_task_manager.py
│   ├── test_time_tracker.py
│   ├── test_statistics.py
│   └── test_ai_suggestions.py
│
├── tasks.json                # Auto-created on first run
├── requirements.txt          # streamlit, pytest
└── README.md
```

---

## Sub-Tasks

---

### Sub-Task 1 — Project Scaffold & Custom Exceptions

**Status:** [ ] pending

**Intent:**
Create the project folder, all empty module files, `requirements.txt`, `README.md`, and the `exceptions.py` module containing every custom exception the app will use. Getting exceptions defined first means every other module can import them cleanly from day one.

**Expected Outcomes:**
- Full folder structure exists at `C:\Users\uadhy\Documents\student-productivity-app`
- `exceptions.py` defines all custom exceptions
- `requirements.txt` lists `streamlit` and `pytest`
- `README.md` contains a one-paragraph project description and run instructions
- All other `.py` files exist as empty stubs (just a module-level docstring)
- `tests/` folder exists with empty stub test files

**Todo List:**
1. Create the root project folder and all sub-folders
2. Create `requirements.txt` with `streamlit` and `pytest`
3. Create `README.md` with project description and `streamlit run app.py` instructions
4. Create `exceptions.py` and define:
   - `TaskNotFoundError(Exception)` — raised when a task_id does not exist
   - `TaskAlreadyCompletedError(Exception)` — raised when completing an already-done task
   - `TimerAlreadyRunningError(Exception)` — raised when starting a timer while one is active
   - `TimerNotRunningError(Exception)` — raised when stopping a timer that was never started
5. Create empty stub files: `task_manager.py`, `time_tracker.py`, `statistics.py`, `ai_suggestions.py`, `data_store.py`, `app.py`
6. Create empty stub test files under `tests/`

**Relevant Context:**
- All other modules will `from exceptions import ...` — so this must be done first
- No logic lives here, only class definitions that extend `Exception`

---

### Sub-Task 2 — `Task` Class and `DataStore` Module

**Status:** [ ] pending

**Intent:**
Define the `Task` data class (the core data model) and the `DataStore` class that saves/loads all tasks to `tasks.json`. These two pieces are the foundation — every other module depends on them.

**Expected Outcomes:**
- `Task` class in `task_manager.py` with all fields and type hints
- `Task` can be converted to a plain dictionary (`to_dict`) and reconstructed from one (`from_dict`)
- `DataStore` class in `data_store.py` can write a list of `Task` objects to `tasks.json` and read them back
- If `tasks.json` does not exist, `DataStore.load_tasks()` returns an empty list (no crash)
- If `tasks.json` is corrupted, `DataStore.load_tasks()` returns an empty list and logs a warning

**Todo List:**
1. In `task_manager.py`, define the `Task` class with these fields and type hints:
   - `task_id: str` — UUID, auto-generated
   - `title: str`
   - `description: str` — defaults to empty string
   - `priority: str` — one of "Low", "Medium", "High"
   - `deadline: date`
   - `is_completed: bool` — defaults to False
   - `created_at: datetime` — auto-set to now
   - `completed_at: datetime | None` — defaults to None
   - `time_spent_seconds: int` — defaults to 0
   - `timer_started_at: datetime | None` — defaults to None; stores when timer was last started; persisted to JSON so timer survives refresh
2. Add `to_dict(self) -> dict` — serializes all fields; converts date/datetime to ISO strings, None stays None
3. Add `from_dict(cls, data: dict) -> Task` as a `@classmethod` — deserializes from dict; parses ISO strings back to date/datetime
4. In `data_store.py`, define `DataStore` with:
   - `FILE_PATH: str` class constant set to `"tasks.json"`
   - `save_tasks(tasks: list[Task]) -> None` — serializes and writes to JSON file
   - `load_tasks() -> list[Task]` — reads file, returns list of Task objects; handles missing/corrupt file gracefully

**Relevant Context:**
- `timer_started_at` field is critical — it is the mechanism that makes timer state survive a Streamlit page refresh
- Use Python's `uuid` module for `task_id` generation
- Use `json` standard library (no external dependency) for file I/O
- `from_dict` must handle the case where `timer_started_at` key is missing in older JSON entries (default to None)

---

### Sub-Task 3 — `TaskManager` Class

**Status:** [ ] pending

**Intent:**
Build the `TaskManager` class that is the single source of truth for the task list. It owns all task CRUD operations (create, read, update, complete) and delegates persistence to `DataStore`. It also contains all input validation logic.

**Expected Outcomes:**
- `TaskManager` loads tasks from `DataStore` on construction
- `add_task` validates inputs, creates a `Task`, saves, and returns it
- `complete_task` marks a task done, records `completed_at`, saves
- `edit_task` updates allowed fields on a pending task, saves
- `get_pending_tasks` and `get_completed_tasks` return correct filtered lists
- `get_task_by_id` raises `TaskNotFoundError` for unknown IDs
- Validation raises `ValueError` with a human-readable message for bad inputs

**Todo List:**
1. Define `TaskManager` class in `task_manager.py` (below `Task`)
2. `__init__(self)` — loads tasks from `DataStore` into `self._tasks: list[Task]`
3. `add_task(title, description, priority, deadline) -> Task`:
   - Validate title: not empty/whitespace, max 100 chars
   - Validate description: max 500 chars if provided
   - Validate priority: must be in `["Low", "Medium", "High"]`
   - Validate deadline: must be >= today (not in the past)
   - Create Task, append to `self._tasks`, call `DataStore.save_tasks`, return the task
4. `complete_task(task_id: str) -> Task`:
   - Call `get_task_by_id` (raises `TaskNotFoundError` if missing)
   - Raise `TaskAlreadyCompletedError` if already done
   - Set `is_completed = True`, `completed_at = datetime.now()`
   - Save and return task
5. `edit_task(task_id, title, description, priority, deadline) -> Task`:
   - Retrieve task; raise `TaskAlreadyCompletedError` if already completed (no editing completed tasks)
   - Run same validation as `add_task`
   - Update fields, save, return task
6. `get_pending_tasks() -> list[Task]` — filter `is_completed == False`
7. `get_completed_tasks() -> list[Task]` — filter `is_completed == True`
8. `get_task_by_id(task_id: str) -> Task` — raise `TaskNotFoundError` if not found
9. `get_all_tasks() -> list[Task]` — return full list

**Relevant Context:**
- All validation lives here — the UI layer should not contain validation logic
- `DataStore.save_tasks(self._tasks)` is called after every mutation
- `edit_task` does NOT reset `time_spent_seconds` or `timer_started_at`

---

### Sub-Task 4 — `TimeTracker` Class

**Status:** [ ] pending

**Intent:**
Build the `TimeTracker` class that manages starting and stopping timers. Because `timer_started_at` is stored on the `Task` object itself (and persisted to JSON), the timer correctly survives Streamlit page refreshes. Only one task can have a running timer at a time.

**Expected Outcomes:**
- `start_timer` sets `timer_started_at` on the task and saves
- `stop_timer` computes elapsed seconds, adds to `time_spent_seconds`, clears `timer_started_at`, and saves
- Starting a timer while one is already running raises `TimerAlreadyRunningError`
- Stopping a timer that is not running raises `TimerNotRunningError`
- `get_active_task_id` returns the task_id whose timer is running, or None
- `get_time_spent` returns total seconds logged (including any currently-running session)

**Todo List:**
1. Define `TimeTracker` in `time_tracker.py`
2. `__init__(self, task_manager: TaskManager)` — stores reference to task_manager
3. `start_timer(task_id: str) -> None`:
   - Get task via `task_manager.get_task_by_id` (raises `TaskNotFoundError` if missing)
   - Raise `TimerAlreadyRunningError` if any task already has `timer_started_at != None`
   - Set `task.timer_started_at = datetime.now()`, save via `DataStore`
4. `stop_timer(task_id: str) -> int`:
   - Get task; raise `TimerNotRunningError` if `task.timer_started_at` is None
   - Compute `elapsed = (datetime.now() - task.timer_started_at).seconds`
   - Add elapsed to `task.time_spent_seconds`; set `task.timer_started_at = None`; save
   - Return elapsed seconds
5. `get_active_task_id() -> str | None`:
   - Iterate all tasks; return `task_id` of first task where `timer_started_at != None`; return None if none
6. `get_time_spent(task_id: str) -> int`:
   - Return `task.time_spent_seconds` (static total only; live elapsed shown separately in UI)
7. `format_seconds(seconds: int) -> str` — helper: converts seconds to `"Xh Ym"` display string

**Relevant Context:**
- `TimeTracker` does not own its own list of tasks — it always reads/writes through `TaskManager`
- After `stop_timer` or `start_timer`, call `DataStore.save_tasks(task_manager.get_all_tasks())` to persist
- Edge case: if `stop_timer` is called and elapsed is 0 (started and stopped instantly), log 0 — do not raise an error

---

### Sub-Task 5 — `Statistics` and `AISuggestion` Classes

**Status:** [ ] pending

**Intent:**
Build the two "intelligence" modules. `Statistics` computes productivity numbers from the task list. `AISuggestion` uses a simple rule-based algorithm (priority score + deadline proximity) to recommend what to work on next and warn about approaching deadlines.

**Expected Outcomes:**
- `Statistics` correctly computes completion %, tasks completed today, and total time tracked today
- Division-by-zero is handled when there are no tasks
- `AISuggestion.suggest_next_task` returns the highest-scored pending task, or a friendly message if all done
- `AISuggestion.get_deadline_warnings` returns tasks due within 24 hours
- `AISuggestion.generate_tip` returns a short, contextual text tip
- Priority scoring: High=3, Medium=2, Low=1; urgency bonus: +3 if due today, +2 if due tomorrow, +1 if due within 3 days

**Todo List:**
1. Define `Statistics` in `statistics.py`:
   - `__init__(self, task_manager: TaskManager)`
   - `completion_percentage() -> float` — `(completed / total) * 100`; return 0.0 if no tasks
   - `tasks_completed_today() -> int` — count tasks where `completed_at.date() == today`
   - `total_time_today_seconds() -> int` — sum `time_spent_seconds` for all tasks that had any timer activity today (use `completed_at` date or creation date as proxy; keep simple)
   - `total_tasks() -> int`
   - `total_completed() -> int`
   - `total_pending() -> int`
2. Define `AISuggestion` in `ai_suggestions.py`:
   - `__init__(self, task_manager: TaskManager)`
   - `_score_task(task: Task) -> int` — private method: priority score + urgency bonus based on days until deadline
   - `suggest_next_task() -> Task | None` — sort pending tasks by score descending; return top task; return None if no pending tasks
   - `get_deadline_warnings() -> list[Task]` — return pending tasks where deadline is within 1 day from today
   - `generate_tip(stats: Statistics) -> str` — returns one of several pre-written tip strings selected by simple rules:
     - 0% complete and 3+ pending: "You have tasks waiting — start with the highest priority one!"
     - 100% complete: "All tasks done! Great work — take a well-earned break."
     - completion < 50%: "You are less than halfway there. Focus on High priority tasks first."
     - completion >= 50%: "Good progress! Keep the momentum going."

**Relevant Context:**
- The "AI" here is entirely deterministic rule-based logic — no external library needed
- `_score_task` is the heart of the suggestion engine; keep the scoring formula simple and documented
- `total_time_today_seconds` can approximate "today" using `created_at.date() == today` for simplicity — document this limitation

---

### Sub-Task 6 — Streamlit UI (`app.py`)

**Status:** [ ] pending

**Intent:**
Build the Streamlit user interface that ties all modules together. The UI is divided into clearly labeled sections using Streamlit's sidebar and tab components. All user interactions call the appropriate class methods.

**Expected Outcomes:**
- App runs with `streamlit run app.py`
- Sidebar shows summary stats and the AI suggestion
- Four tabs: Add Task, View Tasks, Track Time, Statistics
- Add Task tab: form with title, description, priority dropdown, deadline date picker; submits via button
- View Tasks tab: two sections — Pending (with Complete and Edit buttons) and Completed
- Edit mode: clicking Edit on a pending task shows a pre-filled form inline
- Track Time tab: shows pending tasks with Start/Stop timer buttons; shows live elapsed label
- Statistics tab: shows completion %, tasks done today, time tracked today, deadline warnings
- All validation errors shown as `st.error()` messages
- All success actions shown as `st.success()` messages

**Todo List:**
1. In `app.py`, create a module-level helper `get_managers()` that instantiates `TaskManager`, `TimeTracker`, `Statistics`, and `AISuggestion` using `st.session_state` to avoid re-instantiating on every re-run
2. Build the **Sidebar**:
   - Show total tasks, pending count, completion %
   - Show the AI suggestion (next recommended task title + priority)
   - Show deadline warnings as red alert boxes
3. Build **Tab 1 — Add Task**:
   - `st.text_input` for title
   - `st.text_area` for description
   - `st.selectbox` for priority (Low / Medium / High)
   - `st.date_input` for deadline (min_value = today)
   - Submit button calls `task_manager.add_task()`; show success or error
4. Build **Tab 2 — View Tasks**:
   - Section "Pending Tasks": iterate `get_pending_tasks()`; show each as a card with title, priority badge, deadline, time spent
   - Each pending task has a "Mark Complete" button and an "Edit" button
   - "Edit" button sets a `st.session_state` flag and shows an inline edit form pre-filled with current values
   - Section "Completed Tasks": iterate `get_completed_tasks()`; show title, completed_at, time spent
5. Build **Tab 3 — Track Time**:
   - List all pending tasks
   - Show a "Start Timer" button for tasks with no active timer
   - Show a "Stop Timer" button (with live elapsed text) for the currently active task
   - Only one task can show "Stop Timer" at a time (enforced by `TimeTracker`)
6. Build **Tab 4 — Statistics**:
   - Show completion % as a `st.progress` bar
   - Show tasks completed today, time tracked today (formatted)
   - Show the AI tip from `generate_tip()`
   - Show a table of all tasks with their time spent (sorted by time descending)

**Relevant Context:**
- Use `st.session_state` for edit mode flags and active manager instances
- Streamlit re-runs the entire script on every interaction — all state must live in `st.session_state` or be re-loaded from `tasks.json`
- The "live elapsed" for the running timer is computed at render time as `(datetime.now() - task.timer_started_at).seconds` and formatted using `TimeTracker.format_seconds`

---

### Sub-Task 7 — Unit Tests

**Status:** [ ] pending

**Intent:**
Write pytest unit tests covering the core business logic. Tests do NOT test the Streamlit UI — only the Python classes. A temporary file or in-memory mock is used for `DataStore` so tests do not write to the real `tasks.json`.

**Expected Outcomes:**
- `test_task_manager.py` covers: add task (valid), add task (invalid title), add task (past deadline), complete task, complete already-completed task, edit task, edit completed task, get_by_id with unknown id
- `test_time_tracker.py` covers: start timer, stop timer, start timer when one already running, stop timer when not running, elapsed seconds accumulate correctly
- `test_statistics.py` covers: completion % with no tasks (0.0), completion % with mix, tasks_completed_today
- `test_ai_suggestions.py` covers: suggest_next_task with no pending (returns None), scoring prefers High over Low, scoring prefers sooner deadline, generate_tip returns correct string for each scenario
- All tests pass with `pytest` from the project root

**Todo List:**
1. In each test file, use `pytest` fixtures to create a fresh `TaskManager` instance backed by a temporary JSON file (use `tmp_path` pytest fixture)
2. Write tests for `TaskManager` — cover all validation paths and custom exceptions
3. Write tests for `TimeTracker` — cover start, stop, double-start, double-stop
4. Write tests for `Statistics` — cover zero-task edge case and normal cases
5. Write tests for `AISuggestion` — cover scoring logic and tip text selection
6. Confirm all tests pass with `pytest tests/`

**Relevant Context:**
- Use `pytest`'s `tmp_path` fixture to give `DataStore` a temporary file path per test — patch `DataStore.FILE_PATH` or pass the path as a parameter
- Tests should be short and readable — each test tests exactly one behaviour
- Do not test Streamlit UI components — only pure Python logic

---

## Data Flow Summary

```
User Action (Streamlit UI)
        |
        v
  TaskManager / TimeTracker
        |
        v
  Task objects updated in memory
        |
        v
  DataStore.save_tasks() --> tasks.json
        |
        v
  Statistics / AISuggestion read from TaskManager
        |
        v
  UI re-renders with updated data
```

---

## AI Suggestion Scoring Formula

```
score = priority_score + urgency_bonus

priority_score:
  High   = 3
  Medium = 2
  Low    = 1

urgency_bonus:
  days_until_deadline == 0  --> +3  (due today)
  days_until_deadline == 1  --> +2  (due tomorrow)
  days_until_deadline <= 3  --> +1  (due within 3 days)
  otherwise                 --> +0

Highest total score = suggested next task.
Ties broken by earliest created_at.
```

---

## Input Validation Rules Summary

| Field | Rule |
|---|---|
| title | Required, non-empty, max 100 characters |
| description | Optional, max 500 characters |
| priority | Must be exactly "Low", "Medium", or "High" |
| deadline | Must be a valid date >= today |

---

## Custom Exceptions Summary

| Exception | Raised When |
|---|---|
| `TaskNotFoundError` | `get_task_by_id` called with unknown ID |
| `TaskAlreadyCompletedError` | Completing or editing an already-completed task |
| `TimerAlreadyRunningError` | Starting a timer when another is already running |
| `TimerNotRunningError` | Stopping a timer that is not running |
