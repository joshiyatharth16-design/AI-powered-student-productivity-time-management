"""
ai_suggestions.py
-----------------
Generates simple, rule-based productivity suggestions.

There is NO machine learning here — the "AI" is a scoring formula:

    score = priority_score + urgency_bonus

    priority_score : High=3, Medium=2, Low=1
    urgency_bonus  : due today=+3, due tomorrow=+2, due within 3 days=+1

The task with the highest score is the recommended next task.
Ties are broken by earliest created_at.

Plain English tips are also generated based on the student's overall stats.
"""

from datetime import date
from typing import Optional

from task_manager import Task, TaskManager
from statistics import Statistics

# Mapping from priority label to numeric score
PRIORITY_SCORE: dict[str, int] = {"High": 3, "Medium": 2, "Low": 1}


class AISuggestion:
    """
    Provides rule-based productivity suggestions.

    Usage:
        ai = AISuggestion(manager)
        task = ai.suggest_next_task()         # best task to work on now
        warnings = ai.get_deadline_warnings() # tasks due soon
        tip = ai.generate_tip(stats)          # a motivational/practical text tip
    """

    def __init__(self, task_manager: TaskManager) -> None:
        self._manager = task_manager

    # ------------------------------------------------------------------
    # Scoring formula (private)
    # ------------------------------------------------------------------

    @staticmethod
    def _score_task(task: Task) -> int:
        """
        Compute a priority score for a task.

        Higher score = should be worked on sooner.

        Scoring:
          Base score from priority  : High=3, Medium=2, Low=1
          Urgency bonus             : due today=+3, tomorrow=+2, within 3 days=+1
        """
        today = date.today()
        days_until_deadline = (task.deadline - today).days

        priority_score = PRIORITY_SCORE.get(task.priority, 1)

        if days_until_deadline == 0:
            urgency_bonus = 3  # Due today — very urgent
        elif days_until_deadline == 1:
            urgency_bonus = 2  # Due tomorrow
        elif days_until_deadline <= 3:
            urgency_bonus = 1  # Due within 3 days
        else:
            urgency_bonus = 0  # Not urgent yet

        return priority_score + urgency_bonus

    # ------------------------------------------------------------------
    # Public suggestions
    # ------------------------------------------------------------------

    def suggest_next_task(self) -> Optional[Task]:
        """
        Return the single best task to work on right now.

        The best task is the one with the highest score.
        Ties are broken by the earliest created_at time.

        Returns None if there are no pending tasks.
        """
        pending = self._manager.get_pending_tasks()
        if not pending:
            return None

        # Sort by score descending, then by created_at ascending (oldest first)
        sorted_tasks = sorted(
            pending,
            key=lambda t: (-self._score_task(t), t.created_at),
        )
        return sorted_tasks[0]

    def get_deadline_warnings(self) -> list[Task]:
        """
        Return pending tasks whose deadline is today or tomorrow.
        These are shown as urgent warnings in the UI.
        """
        today = date.today()
        warnings: list[Task] = []
        for task in self._manager.get_pending_tasks():
            days_left = (task.deadline - today).days
            if 0 <= days_left <= 1:
                warnings.append(task)
        return warnings

    def get_overdue_tasks(self) -> list[Task]:
        """
        Return pending tasks whose deadline has already passed.
        A deadline in the past means the task is overdue.
        """
        today = date.today()
        return [
            t for t in self._manager.get_pending_tasks()
            if t.deadline < today
        ]

    def generate_tip(self, stats: Statistics) -> str:
        """
        Return a short, personalised productivity tip based on the
        student's current statistics.

        The tip is chosen by checking a series of simple conditions.
        The first condition that matches wins.
        """
        total = stats.total_tasks()
        pending = stats.total_pending()
        completed = stats.total_completed()
        pct = stats.completion_percentage()
        overdue = self.get_overdue_tasks()
        warnings = self.get_deadline_warnings()

        # --- Rule 1: No tasks at all ---
        if total == 0:
            return (
                "👋 Welcome! Start by adding your first task. "
                "Break your study session into small tasks to stay focused."
            )

        # --- Rule 2: Overdue tasks exist ---
        if overdue:
            names = ", ".join(f"'{t.title}'" for t in overdue[:2])
            extra = f" (and {len(overdue) - 2} more)" if len(overdue) > 2 else ""
            return (
                f"⚠️ You have {len(overdue)} overdue task(s): {names}{extra}. "
                "Try to complete these first or update their deadlines."
            )

        # --- Rule 3: Deadline warnings ---
        if warnings:
            names = ", ".join(f"'{t.title}'" for t in warnings[:2])
            extra = f" (and {len(warnings) - 2} more)" if len(warnings) > 2 else ""
            return (
                f"⏰ Deadline alert! Task(s) due very soon: {names}{extra}. "
                "Focus on these today."
            )

        # --- Rule 4: All tasks done ---
        if pending == 0 and completed > 0:
            return (
                "🎉 All tasks completed! Great work. "
                "Take a short break — you have earned it!"
            )

        # --- Rule 5: Too many pending tasks ---
        if pending >= 5:
            return (
                f"📋 You have {pending} pending tasks. "
                "That is quite a lot! Try to finish at least 2–3 today. "
                "Start with the highest priority one."
            )

        # --- Rule 6: Low completion ---
        if pct < 30 and total >= 3:
            return (
                f"📚 You have completed {pct}% of your tasks. "
                "Pick the most urgent task and start with just 25 minutes of focused work."
            )

        # --- Rule 7: Good progress ---
        if pct >= 70:
            return (
                f"✅ Excellent progress — {pct}% done! "
                "Keep going, you are almost there."
            )

        # --- Default motivational tip ---
        next_task = self.suggest_next_task()
        if next_task:
            return (
                f"💡 Suggested next task: '{next_task.title}' "
                f"({next_task.priority} priority, due {next_task.deadline}). "
                "Try to give it your full attention for 30 minutes."
            )

        return "📖 Keep studying steadily. Consistent effort beats last-minute cramming!"
