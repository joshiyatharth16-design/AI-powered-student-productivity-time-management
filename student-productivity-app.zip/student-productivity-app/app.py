"""
app.py
------
Streamlit UI for the AI-Powered Student Productivity & Time Management App.

Run with:
    streamlit run app.py

Structure:
    - Sidebar   : summary stats + AI suggestion + deadline warnings
    - Tab 1     : Add Task
    - Tab 2     : View Tasks (pending with Edit/Complete/Delete, completed)
    - Tab 3     : Track Time
    - Tab 4     : Statistics

All business logic lives in the other modules.
This file only handles displaying data and calling the appropriate methods.
"""

import sys
import os

# Make sure Python can find our modules when the working directory differs
sys.path.insert(0, os.path.dirname(__file__))

from datetime import date, datetime
from typing import Optional

import streamlit as st

from task_manager import TaskManager, VALID_PRIORITIES
from time_tracker import TimeTracker
from statistics import Statistics
from ai_suggestions import AISuggestion
from exceptions import (
    TaskNotFoundError,
    TaskAlreadyCompletedError,
    TimerAlreadyRunningError,
    TimerNotRunningError,
)

# ---------------------------------------------------------------------------
# Page config — must be the very first Streamlit call
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title="Student Productivity App",
    page_icon="📚",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Session-state helpers
# ---------------------------------------------------------------------------

def _init_state() -> None:
    """
    Initialise all session-state keys once per browser session.
    Streamlit re-runs the whole script on every interaction, so we guard
    with 'if key not in st.session_state'.
    """
    if "manager" not in st.session_state:
        st.session_state.manager = TaskManager()
    if "tracker" not in st.session_state:
        st.session_state.tracker = TimeTracker(st.session_state.manager)
    if "edit_task_id" not in st.session_state:
        st.session_state.edit_task_id = None   # tracks which task is being edited
    if "success_msg" not in st.session_state:
        st.session_state.success_msg = None
    if "error_msg" not in st.session_state:
        st.session_state.error_msg = None


def _flash_success(msg: str) -> None:
    st.session_state.success_msg = msg


def _flash_error(msg: str) -> None:
    st.session_state.error_msg = msg


def _show_flash() -> None:
    """Display and immediately clear any pending flash messages."""
    if st.session_state.success_msg:
        st.success(st.session_state.success_msg)
        st.session_state.success_msg = None
    if st.session_state.error_msg:
        st.error(st.session_state.error_msg)
        st.session_state.error_msg = None


# ---------------------------------------------------------------------------
# Priority badge colour helper
# ---------------------------------------------------------------------------

PRIORITY_COLOURS: dict[str, str] = {
    "High": "🔴",
    "Medium": "🟡",
    "Low": "🟢",
}


def _priority_badge(priority: str) -> str:
    return f"{PRIORITY_COLOURS.get(priority, '')} {priority}"


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

def _render_sidebar(
    manager: TaskManager,
    stats: Statistics,
    ai: AISuggestion,
) -> None:
    with st.sidebar:
        st.title("📚 Student Planner")
        st.markdown("---")

        # --- Summary numbers ---
        col1, col2 = st.columns(2)
        col1.metric("Total Tasks", stats.total_tasks())
        col2.metric("Pending", stats.total_pending())
        col1.metric("Completed", stats.total_completed())
        col2.metric("Done %", f"{stats.completion_percentage()}%")

        st.markdown("---")

        # --- AI Suggestion ---
        st.subheader("🤖 AI Suggestion")
        next_task = ai.suggest_next_task()
        if next_task:
            st.info(
                f"**Work on:** {next_task.title}\n\n"
                f"Priority: {_priority_badge(next_task.priority)}  \n"
                f"Deadline: {next_task.deadline}"
            )
        else:
            st.success("All tasks done! 🎉")

        # --- Deadline warnings ---
        warnings = ai.get_deadline_warnings()
        overdue = ai.get_overdue_tasks()

        if overdue:
            st.markdown("---")
            st.subheader("🚨 Overdue")
            for t in overdue:
                st.error(f"**{t.title}** — was due {t.deadline}")

        if warnings:
            st.markdown("---")
            st.subheader("⏰ Due Soon")
            for t in warnings:
                days = (t.deadline - date.today()).days
                label = "Today" if days == 0 else "Tomorrow"
                st.warning(f"**{t.title}** — due {label}")


# ---------------------------------------------------------------------------
# Tab 1 — Add Task
# ---------------------------------------------------------------------------

def _tab_add_task(manager: TaskManager) -> None:
    st.header("➕ Add New Task")
    _show_flash()

    with st.form("add_task_form", clear_on_submit=True):
        title = st.text_input("Task Title *", max_chars=100, placeholder="e.g. Study OS Chapter 3")
        description = st.text_area("Description (optional)", max_chars=500, placeholder="Notes about this task...")
        priority = st.selectbox("Priority", VALID_PRIORITIES, index=1)  # default: Medium
        deadline = st.date_input("Deadline", min_value=date.today(), value=date.today())

        submitted = st.form_submit_button("Add Task", use_container_width=True)

    if submitted:
        try:
            task = manager.add_task(title, description, priority, deadline)
            _flash_success(f"Task '{task.title}' added successfully!")
            st.rerun()
        except ValueError as e:
            _flash_error(str(e))
            st.rerun()


# ---------------------------------------------------------------------------
# Tab 2 — View Tasks
# ---------------------------------------------------------------------------

def _render_edit_form(manager: TaskManager, task_id: str) -> None:
    """Render an inline edit form for the given task."""
    try:
        task = manager.get_task_by_id(task_id)
    except TaskNotFoundError:
        st.session_state.edit_task_id = None
        return

    st.markdown(f"#### ✏️ Editing: *{task.title}*")
    with st.form(f"edit_form_{task_id}"):
        new_title = st.text_input("Title *", value=task.title, max_chars=100)
        new_desc = st.text_area("Description", value=task.description, max_chars=500)
        priority_index = VALID_PRIORITIES.index(task.priority) if task.priority in VALID_PRIORITIES else 1
        new_priority = st.selectbox("Priority", VALID_PRIORITIES, index=priority_index)
        new_deadline = st.date_input(
            "Deadline",
            value=task.deadline,
            min_value=date.today(),
        )
        col_save, col_cancel = st.columns(2)
        save = col_save.form_submit_button("💾 Save Changes", use_container_width=True)
        cancel = col_cancel.form_submit_button("✖ Cancel", use_container_width=True)

    if save:
        try:
            manager.edit_task(task_id, new_title, new_desc, new_priority, new_deadline)
            st.session_state.edit_task_id = None
            _flash_success(f"Task '{new_title}' updated!")
            st.rerun()
        except (ValueError, TaskAlreadyCompletedError, TaskNotFoundError) as e:
            _flash_error(str(e))
            st.rerun()

    if cancel:
        st.session_state.edit_task_id = None
        st.rerun()


def _tab_view_tasks(manager: TaskManager, tracker: TimeTracker) -> None:
    st.header("📋 View Tasks")
    _show_flash()

    # ---- Pending tasks ----
    st.subheader("🔵 Pending Tasks")
    pending = manager.get_pending_tasks()

    if not pending:
        st.info("No pending tasks. Add one from the 'Add Task' tab!")
    else:
        for task in pending:
            days_left = (task.deadline - date.today()).days
            if days_left < 0:
                deadline_label = f"🚨 Overdue by {abs(days_left)} day(s)"
            elif days_left == 0:
                deadline_label = "⏰ Due Today"
            elif days_left == 1:
                deadline_label = "⚠️ Due Tomorrow"
            else:
                deadline_label = f"📅 {task.deadline} ({days_left} days left)"

            time_label = TimeTracker.format_seconds(task.time_spent_seconds)

            with st.container(border=True):
                col_info, col_actions = st.columns([3, 2])

                with col_info:
                    st.markdown(f"**{task.title}**")
                    st.caption(task.description or "_No description_")
                    st.markdown(
                        f"{_priority_badge(task.priority)}  &nbsp;|&nbsp;  "
                        f"{deadline_label}  &nbsp;|&nbsp;  "
                        f"⏱ {time_label}"
                    )

                with col_actions:
                    btn_complete = st.button("✅ Complete", key=f"complete_{task.task_id}", use_container_width=True)
                    btn_edit = st.button("✏️ Edit", key=f"edit_{task.task_id}", use_container_width=True)
                    btn_delete = st.button("🗑️ Delete", key=f"delete_{task.task_id}", use_container_width=True)

                    if btn_complete:
                        try:
                            # Stop timer if it's running for this task
                            if tracker.get_active_task_id() == task.task_id:
                                tracker.stop_timer(task.task_id)
                            manager.complete_task(task.task_id)
                            _flash_success(f"'{task.title}' marked as complete!")
                            st.rerun()
                        except (TaskNotFoundError, TaskAlreadyCompletedError) as e:
                            _flash_error(str(e))
                            st.rerun()

                    if btn_edit:
                        st.session_state.edit_task_id = task.task_id
                        st.rerun()

                    if btn_delete:
                        try:
                            # Stop timer if running for this task
                            if tracker.get_active_task_id() == task.task_id:
                                tracker.stop_timer(task.task_id)
                            manager.delete_task(task.task_id)
                            _flash_success(f"'{task.title}' deleted.")
                            st.rerun()
                        except TaskNotFoundError as e:
                            _flash_error(str(e))
                            st.rerun()

            # Show edit form directly below the task being edited
            if st.session_state.edit_task_id == task.task_id:
                _render_edit_form(manager, task.task_id)

    st.markdown("---")

    # ---- Completed tasks ----
    st.subheader("✅ Completed Tasks")
    completed = manager.get_completed_tasks()

    if not completed:
        st.info("No completed tasks yet. Keep going!")
    else:
        for task in completed:
            time_label = TimeTracker.format_seconds(task.time_spent_seconds)
            completed_label = (
                task.completed_at.strftime("%d %b %Y, %H:%M")
                if task.completed_at else "—"
            )
            with st.container(border=True):
                col_info, col_del = st.columns([4, 1])
                with col_info:
                    st.markdown(f"~~{task.title}~~  ✅")
                    st.caption(task.description or "_No description_")
                    st.markdown(
                        f"{_priority_badge(task.priority)}  &nbsp;|&nbsp;  "
                        f"Completed: {completed_label}  &nbsp;|&nbsp;  "
                        f"⏱ {time_label}"
                    )
                with col_del:
                    if st.button("🗑️", key=f"del_done_{task.task_id}", help="Delete", use_container_width=True):
                        try:
                            manager.delete_task(task.task_id)
                            _flash_success(f"'{task.title}' deleted.")
                            st.rerun()
                        except TaskNotFoundError as e:
                            _flash_error(str(e))
                            st.rerun()


# ---------------------------------------------------------------------------
# Tab 3 — Track Time
# ---------------------------------------------------------------------------

def _tab_track_time(manager: TaskManager, tracker: TimeTracker) -> None:
    st.header("⏱️ Track Study Time")
    _show_flash()

    st.markdown(
        "Start a timer when you begin studying a task. "
        "Stop it when you take a break or finish. "
        "Only **one timer** can run at a time."
    )

    pending = manager.get_pending_tasks()
    active_id = tracker.get_active_task_id()

    if not pending:
        st.info("No pending tasks. Add a task first!")
        return

    for task in pending:
        is_active = (task.task_id == active_id)
        time_label = TimeTracker.format_seconds(task.time_spent_seconds)

        with st.container(border=True):
            col_info, col_btn = st.columns([3, 1])

            with col_info:
                st.markdown(f"**{task.title}**")
                st.caption(
                    f"{_priority_badge(task.priority)}  |  "
                    f"Deadline: {task.deadline}  |  "
                    f"Total logged: ⏱ {time_label}"
                )
                if is_active:
                    live_secs = tracker.get_live_elapsed_seconds(task.task_id)
                    st.markdown(
                        f"🟢 **Timer running** — current session: "
                        f"**{TimeTracker.format_seconds(live_secs)}**"
                    )

            with col_btn:
                if is_active:
                    if st.button("⏹️ Stop", key=f"stop_{task.task_id}", use_container_width=True):
                        try:
                            elapsed = tracker.stop_timer(task.task_id)
                            _flash_success(
                                f"Timer stopped for '{task.title}'. "
                                f"Session: {TimeTracker.format_seconds(elapsed)}"
                            )
                            st.rerun()
                        except TimerNotRunningError as e:
                            _flash_error(str(e))
                            st.rerun()
                else:
                    # Disable the start button if a different timer is running
                    disabled = active_id is not None
                    if st.button(
                        "▶️ Start",
                        key=f"start_{task.task_id}",
                        use_container_width=True,
                        disabled=disabled,
                        help="Stop the running timer first" if disabled else "",
                    ):
                        try:
                            tracker.start_timer(task.task_id)
                            _flash_success(f"Timer started for '{task.title}'.")
                            st.rerun()
                        except TimerAlreadyRunningError as e:
                            _flash_error(str(e))
                            st.rerun()


# ---------------------------------------------------------------------------
# Tab 4 — Statistics
# ---------------------------------------------------------------------------

def _tab_statistics(
    stats: Statistics,
    ai: AISuggestion,
    tracker: TimeTracker,
) -> None:
    st.header("📊 Productivity Statistics")

    # --- Today's summary ---
    st.subheader("Today's Summary")
    col1, col2, col3 = st.columns(3)
    col1.metric("Tasks Completed Today", stats.tasks_completed_today())
    col2.metric(
        "Time Studied Today",
        TimeTracker.format_seconds(stats.total_time_today_seconds()),
    )
    col3.metric("Overall Progress", f"{stats.completion_percentage()}%")

    # --- Progress bar ---
    pct = stats.completion_percentage() / 100.0
    st.progress(pct, text=f"{stats.completion_percentage()}% of all tasks completed")

    st.markdown("---")

    # --- AI Productivity Tip ---
    st.subheader("🤖 AI Productivity Tip")
    tip = ai.generate_tip(stats)
    st.info(tip)

    st.markdown("---")

    # --- All tasks time table ---
    st.subheader("⏱ Time Logged per Task")
    all_tasks = stats._manager.get_all_tasks()
    if not all_tasks:
        st.info("No tasks yet.")
    else:
        rows = []
        for t in sorted(all_tasks, key=lambda x: x.time_spent_seconds, reverse=True):
            status = "✅ Done" if t.is_completed else "🔵 Pending"
            rows.append({
                "Task": t.title,
                "Priority": t.priority,
                "Status": status,
                "Deadline": str(t.deadline),
                "Time Logged": TimeTracker.format_seconds(t.time_spent_seconds),
            })
        st.dataframe(rows, use_container_width=True, hide_index=True)

    st.markdown("---")

    # --- Upcoming deadline section ---
    st.subheader("📅 Upcoming Deadlines (Next 7 Days)")
    upcoming = stats.tasks_with_upcoming_deadlines(within_days=7)
    if not upcoming:
        st.info("No deadlines in the next 7 days.")
    else:
        for t in sorted(upcoming, key=lambda x: x.deadline):
            days_left = (t.deadline - date.today()).days
            label = "Today" if days_left == 0 else f"in {days_left} day(s)"
            st.warning(f"**{t.title}** — due {label} ({t.deadline})  |  {_priority_badge(t.priority)}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    _init_state()

    manager: TaskManager = st.session_state.manager
    tracker: TimeTracker = st.session_state.tracker
    stats = Statistics(manager)
    ai = AISuggestion(manager)

    # Reload manager from disk on every run so changes from other sessions
    # (or after a restart) are reflected immediately
    manager._tasks = manager._load_from_store()

    _render_sidebar(manager, stats, ai)

    st.title("📚 Student Productivity App")
    st.caption("AI-Powered Task & Time Management for B.Tech Students")

    tab_add, tab_view, tab_time, tab_stats = st.tabs([
        "➕ Add Task",
        "📋 View Tasks",
        "⏱️ Track Time",
        "📊 Statistics",
    ])

    with tab_add:
        _tab_add_task(manager)

    with tab_view:
        _tab_view_tasks(manager, tracker)

    with tab_time:
        _tab_track_time(manager, tracker)

    with tab_stats:
        _tab_statistics(stats, ai, tracker)


if __name__ == "__main__":
    main()
