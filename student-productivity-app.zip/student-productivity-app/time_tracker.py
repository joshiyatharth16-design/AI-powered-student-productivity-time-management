"""
time_tracker.py
---------------
Manages start/stop timers for tasks.

Key design decision:
  The start time is stored directly on the Task object (task.timer_started_at)
  and persisted to tasks.json.  This means a running timer survives a
  Streamlit page refresh — the elapsed time is simply recalculated from
  the stored start time whenever the page re-renders.

Only ONE task can have a running timer at a time.
"""

from datetime import datetime
from typing import Optional

from exceptions import TimerAlreadyRunningError, TimerNotRunningError, TaskNotFoundError
from task_manager import Task, TaskManager


class TimeTracker:
    """
    Controls the study timer for tasks.

    Usage:
        tracker = TimeTracker(manager)
        tracker.start_timer(task_id)   # start timing
        tracker.stop_timer(task_id)    # stop and save elapsed seconds
        tracker.get_active_task_id()   # which task is currently being timed?
        TimeTracker.format_seconds(90) # "1m 30s"
    """

    def __init__(self, task_manager: TaskManager) -> None:
        self._manager = task_manager

    # ------------------------------------------------------------------
    # Timer control
    # ------------------------------------------------------------------

    def start_timer(self, task_id: str) -> None:
        """
        Start the timer for the given task.

        Raises:
            TaskNotFoundError       : If the task_id does not exist.
            TimerAlreadyRunningError: If any task already has a running timer.
        """
        # Check if another task's timer is already running
        active_id = self.get_active_task_id()
        if active_id is not None:
            raise TimerAlreadyRunningError(
                "A timer is already running. Please stop it before starting another."
            )

        task: Task = self._manager.get_task_by_id(task_id)
        task.timer_started_at = datetime.now()
        # Save immediately so the start time survives a page refresh
        self._manager._save()

    def stop_timer(self, task_id: str) -> int:
        """
        Stop the timer for the given task and accumulate the elapsed seconds.

        Returns:
            The number of seconds elapsed in this session.

        Raises:
            TaskNotFoundError  : If the task_id does not exist.
            TimerNotRunningError: If this task's timer is not running.
        """
        task: Task = self._manager.get_task_by_id(task_id)

        if task.timer_started_at is None:
            raise TimerNotRunningError(
                "The timer for this task is not running."
            )

        elapsed: int = int((datetime.now() - task.timer_started_at).total_seconds())
        # Guard: elapsed should never be negative; treat negative as 0
        elapsed = max(0, elapsed)

        task.time_spent_seconds += elapsed
        task.timer_started_at = None
        self._manager._save()
        return elapsed

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_active_task_id(self) -> Optional[str]:
        """
        Return the task_id of the task whose timer is currently running,
        or None if no timer is active.
        """
        for task in self._manager.get_all_tasks():
            if task.timer_started_at is not None:
                return task.task_id
        return None

    def get_live_elapsed_seconds(self, task_id: str) -> int:
        """
        Return how many seconds have elapsed since the timer was started
        for the given task.  Returns 0 if the timer is not running.

        This is called every time the UI re-renders so the displayed
        time updates on each Streamlit refresh.
        """
        task: Task = self._manager.get_task_by_id(task_id)
        if task.timer_started_at is None:
            return 0
        elapsed = int((datetime.now() - task.timer_started_at).total_seconds())
        return max(0, elapsed)

    # ------------------------------------------------------------------
    # Formatting helper
    # ------------------------------------------------------------------

    @staticmethod
    def format_seconds(seconds: int) -> str:
        """
        Convert a number of seconds to a human-readable string.

        Examples:
            45        -> "45s"
            90        -> "1m 30s"
            3661      -> "1h 1m 1s"
        """
        seconds = max(0, int(seconds))
        hours, remainder = divmod(seconds, 3600)
        minutes, secs = divmod(remainder, 60)

        if hours > 0:
            return f"{hours}h {minutes}m {secs}s"
        if minutes > 0:
            return f"{minutes}m {secs}s"
        return f"{secs}s"
