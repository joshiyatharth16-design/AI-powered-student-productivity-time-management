"""
tests/test_statistics.py
------------------------
Unit tests for the Statistics class.
"""

import pytest
from datetime import date, timedelta, datetime

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from task_manager import TaskManager
from data_store import DataStore
from statistics import Statistics


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def store(tmp_path):
    return DataStore(file_path=str(tmp_path / "tasks.json"))


@pytest.fixture
def manager(store):
    return TaskManager(store=store)


@pytest.fixture
def stats(manager):
    return Statistics(manager)


def tomorrow() -> date:
    return date.today() + timedelta(days=1)


def in_days(n: int) -> date:
    return date.today() + timedelta(days=n)


# ---------------------------------------------------------------------------
# completion_percentage
# ---------------------------------------------------------------------------

class TestCompletionPercentage:
    def test_no_tasks_returns_zero(self, stats):
        assert stats.completion_percentage() == 0.0

    def test_all_pending_returns_zero(self, manager, stats):
        manager.add_task("T1", "", "Low", tomorrow())
        manager.add_task("T2", "", "Low", tomorrow())
        assert stats.completion_percentage() == 0.0

    def test_all_completed_returns_100(self, manager, stats):
        t1 = manager.add_task("T1", "", "Low", tomorrow())
        t2 = manager.add_task("T2", "", "Low", tomorrow())
        manager.complete_task(t1.task_id)
        manager.complete_task(t2.task_id)
        assert stats.completion_percentage() == 100.0

    def test_half_completed(self, manager, stats):
        t1 = manager.add_task("T1", "", "Low", tomorrow())
        manager.add_task("T2", "", "Low", tomorrow())
        manager.complete_task(t1.task_id)
        assert stats.completion_percentage() == 50.0

    def test_one_of_three_completed(self, manager, stats):
        t1 = manager.add_task("T1", "", "Low", tomorrow())
        manager.add_task("T2", "", "Low", tomorrow())
        manager.add_task("T3", "", "Low", tomorrow())
        manager.complete_task(t1.task_id)
        assert stats.completion_percentage() == round(1 / 3 * 100, 1)


# ---------------------------------------------------------------------------
# total_tasks / total_completed / total_pending
# ---------------------------------------------------------------------------

class TestCounts:
    def test_counts_empty(self, stats):
        assert stats.total_tasks() == 0
        assert stats.total_completed() == 0
        assert stats.total_pending() == 0

    def test_counts_with_tasks(self, manager, stats):
        t1 = manager.add_task("T1", "", "Low", tomorrow())
        manager.add_task("T2", "", "Low", tomorrow())
        manager.complete_task(t1.task_id)
        assert stats.total_tasks() == 2
        assert stats.total_completed() == 1
        assert stats.total_pending() == 1


# ---------------------------------------------------------------------------
# tasks_completed_today
# ---------------------------------------------------------------------------

class TestTasksCompletedToday:
    def test_none_completed_today(self, stats):
        assert stats.tasks_completed_today() == 0

    def test_completed_today(self, manager, stats):
        t = manager.add_task("T", "", "Low", tomorrow())
        manager.complete_task(t.task_id)
        # completed_at is set to datetime.now() by complete_task
        assert stats.tasks_completed_today() == 1

    def test_only_counts_today_not_old(self, manager, stats):
        t1 = manager.add_task("T1", "", "Low", tomorrow())
        manager.complete_task(t1.task_id)

        # Simulate a task completed yesterday by directly setting completed_at
        t2 = manager.add_task("T2", "", "Low", tomorrow())
        manager.complete_task(t2.task_id)
        t2_obj = manager.get_task_by_id(t2.task_id)
        t2_obj.completed_at = datetime.combine(
            date.today() - timedelta(days=1), datetime.min.time()
        )
        manager._save()

        assert stats.tasks_completed_today() == 1


# ---------------------------------------------------------------------------
# tasks_with_upcoming_deadlines
# ---------------------------------------------------------------------------

class TestUpcomingDeadlines:
    def test_no_upcoming(self, manager, stats):
        manager.add_task("Far", "", "Low", in_days(10))
        assert stats.tasks_with_upcoming_deadlines(within_days=2) == []

    def test_due_today_included(self, manager, stats):
        t = manager.add_task("Due Today", "", "High", date.today())
        result = stats.tasks_with_upcoming_deadlines(within_days=2)
        assert any(x.task_id == t.task_id for x in result)

    def test_completed_not_included(self, manager, stats):
        t = manager.add_task("Done", "", "High", date.today())
        manager.complete_task(t.task_id)
        result = stats.tasks_with_upcoming_deadlines(within_days=2)
        assert result == []
