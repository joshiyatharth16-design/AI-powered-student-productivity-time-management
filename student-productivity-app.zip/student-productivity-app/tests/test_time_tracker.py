"""
tests/test_time_tracker.py
--------------------------
Unit tests for the TimeTracker class.
"""

import time
import pytest
from datetime import date, timedelta, datetime

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from task_manager import TaskManager
from data_store import DataStore
from time_tracker import TimeTracker
from exceptions import TimerAlreadyRunningError, TimerNotRunningError


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def store(tmp_path):
    return DataStore(file_path=str(tmp_path / "tasks.json"))


@pytest.fixture
def manager(store):
    return TaskManager(store=store)


@pytest.fixture
def tracker(manager):
    return TimeTracker(manager)


def tomorrow() -> date:
    return date.today() + timedelta(days=1)


# ---------------------------------------------------------------------------
# format_seconds (static helper)
# ---------------------------------------------------------------------------

class TestFormatSeconds:
    def test_zero_seconds(self):
        assert TimeTracker.format_seconds(0) == "0s"

    def test_seconds_only(self):
        assert TimeTracker.format_seconds(45) == "45s"

    def test_minutes_and_seconds(self):
        assert TimeTracker.format_seconds(90) == "1m 30s"

    def test_hours_minutes_seconds(self):
        assert TimeTracker.format_seconds(3661) == "1h 1m 1s"

    def test_negative_treated_as_zero(self):
        assert TimeTracker.format_seconds(-10) == "0s"

    def test_exact_one_hour(self):
        assert TimeTracker.format_seconds(3600) == "1h 0m 0s"


# ---------------------------------------------------------------------------
# start_timer / stop_timer
# ---------------------------------------------------------------------------

class TestTimerControl:
    def test_start_timer_sets_timer_started_at(self, manager, tracker):
        task = manager.add_task("T", "", "Low", tomorrow())
        tracker.start_timer(task.task_id)
        updated = manager.get_task_by_id(task.task_id)
        assert updated.timer_started_at is not None

    def test_stop_timer_clears_timer_started_at(self, manager, tracker):
        task = manager.add_task("T", "", "Low", tomorrow())
        tracker.start_timer(task.task_id)
        tracker.stop_timer(task.task_id)
        updated = manager.get_task_by_id(task.task_id)
        assert updated.timer_started_at is None

    def test_stop_timer_accumulates_seconds(self, manager, tracker):
        task = manager.add_task("T", "", "Low", tomorrow())
        tracker.start_timer(task.task_id)
        time.sleep(1)  # wait 1 second so elapsed > 0
        elapsed = tracker.stop_timer(task.task_id)
        updated = manager.get_task_by_id(task.task_id)
        assert elapsed >= 1
        assert updated.time_spent_seconds >= 1

    def test_stop_timer_accumulates_across_sessions(self, manager, tracker):
        task = manager.add_task("T", "", "Low", tomorrow())
        # Session 1
        tracker.start_timer(task.task_id)
        time.sleep(1)
        tracker.stop_timer(task.task_id)
        # Session 2
        tracker.start_timer(task.task_id)
        time.sleep(1)
        tracker.stop_timer(task.task_id)
        updated = manager.get_task_by_id(task.task_id)
        assert updated.time_spent_seconds >= 2

    def test_start_timer_while_running_raises(self, manager, tracker):
        t1 = manager.add_task("T1", "", "Low", tomorrow())
        t2 = manager.add_task("T2", "", "High", tomorrow())
        tracker.start_timer(t1.task_id)
        with pytest.raises(TimerAlreadyRunningError):
            tracker.start_timer(t2.task_id)
        tracker.stop_timer(t1.task_id)  # cleanup

    def test_stop_timer_not_running_raises(self, manager, tracker):
        task = manager.add_task("T", "", "Low", tomorrow())
        with pytest.raises(TimerNotRunningError):
            tracker.stop_timer(task.task_id)

    def test_instant_start_stop_gives_zero_or_positive(self, manager, tracker):
        task = manager.add_task("T", "", "Low", tomorrow())
        tracker.start_timer(task.task_id)
        elapsed = tracker.stop_timer(task.task_id)
        assert elapsed >= 0  # never negative


# ---------------------------------------------------------------------------
# get_active_task_id
# ---------------------------------------------------------------------------

class TestGetActiveTaskId:
    def test_no_active_timer(self, manager, tracker):
        assert tracker.get_active_task_id() is None

    def test_active_timer_returned(self, manager, tracker):
        task = manager.add_task("T", "", "Low", tomorrow())
        tracker.start_timer(task.task_id)
        assert tracker.get_active_task_id() == task.task_id
        tracker.stop_timer(task.task_id)

    def test_after_stop_no_active_timer(self, manager, tracker):
        task = manager.add_task("T", "", "Low", tomorrow())
        tracker.start_timer(task.task_id)
        tracker.stop_timer(task.task_id)
        assert tracker.get_active_task_id() is None


# ---------------------------------------------------------------------------
# get_live_elapsed_seconds
# ---------------------------------------------------------------------------

class TestLiveElapsed:
    def test_not_running_returns_zero(self, manager, tracker):
        task = manager.add_task("T", "", "Low", tomorrow())
        assert tracker.get_live_elapsed_seconds(task.task_id) == 0

    def test_running_returns_positive(self, manager, tracker):
        task = manager.add_task("T", "", "Low", tomorrow())
        tracker.start_timer(task.task_id)
        time.sleep(1)
        elapsed = tracker.get_live_elapsed_seconds(task.task_id)
        assert elapsed >= 1
        tracker.stop_timer(task.task_id)
