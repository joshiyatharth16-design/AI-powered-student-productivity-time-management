"""
tests/test_ai_suggestions.py
-----------------------------
Unit tests for the AISuggestion class.
"""

import pytest
from datetime import date, timedelta

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from task_manager import TaskManager
from data_store import DataStore
from statistics import Statistics
from ai_suggestions import AISuggestion, PRIORITY_SCORE


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def store(tmp_path):
    return DataStore(file_path=str(tmp_path / "tasks.json"))


@pytest.fixture
def manager(store):
    return TaskManager(store=store)


@pytest.fixture
def ai(manager):
    return AISuggestion(manager)


@pytest.fixture
def stats(manager):
    return Statistics(manager)


def in_days(n: int) -> date:
    return date.today() + timedelta(days=n)


def tomorrow() -> date:
    return in_days(1)


# ---------------------------------------------------------------------------
# _score_task (scoring formula)
# ---------------------------------------------------------------------------

class TestScoring:
    def test_high_priority_scores_higher_than_low(self, manager, ai):
        t_high = manager.add_task("High Task", "", "High", in_days(10))
        t_low = manager.add_task("Low Task", "", "Low", in_days(10))
        assert ai._score_task(t_high) > ai._score_task(t_low)

    def test_medium_priority_between_low_and_high(self, manager, ai):
        t_med = manager.add_task("Med", "", "Medium", in_days(10))
        t_low = manager.add_task("Low", "", "Low", in_days(10))
        t_high = manager.add_task("High", "", "High", in_days(10))
        assert ai._score_task(t_low) < ai._score_task(t_med) < ai._score_task(t_high)

    def test_urgency_bonus_for_today(self, manager, ai):
        t_today = manager.add_task("Today", "", "Low", date.today())
        t_far = manager.add_task("Far", "", "Low", in_days(30))
        assert ai._score_task(t_today) > ai._score_task(t_far)

    def test_urgency_bonus_today_greater_than_tomorrow(self, manager, ai):
        t_today = manager.add_task("Today", "", "Low", date.today())
        t_tmrw = manager.add_task("Tomorrow", "", "Low", tomorrow())
        assert ai._score_task(t_today) > ai._score_task(t_tmrw)

    def test_urgency_bonus_tomorrow_greater_than_next_week(self, manager, ai):
        t_tmrw = manager.add_task("Tomorrow", "", "Low", tomorrow())
        t_week = manager.add_task("Week", "", "Low", in_days(7))
        assert ai._score_task(t_tmrw) > ai._score_task(t_week)

    def test_high_priority_far_deadline_vs_low_priority_today(self, manager, ai):
        # High priority with far deadline: score = 3 + 0 = 3
        t_high_far = manager.add_task("High Far", "", "High", in_days(30))
        # Low priority due today: score = 1 + 3 = 4
        t_low_today = manager.add_task("Low Today", "", "Low", date.today())
        assert ai._score_task(t_low_today) > ai._score_task(t_high_far)


# ---------------------------------------------------------------------------
# suggest_next_task
# ---------------------------------------------------------------------------

class TestSuggestNextTask:
    def test_no_tasks_returns_none(self, ai):
        assert ai.suggest_next_task() is None

    def test_all_completed_returns_none(self, manager, ai):
        t = manager.add_task("T", "", "Low", tomorrow())
        manager.complete_task(t.task_id)
        assert ai.suggest_next_task() is None

    def test_suggests_highest_scored_task(self, manager, ai):
        manager.add_task("Low Far", "", "Low", in_days(30))
        t_high = manager.add_task("High Soon", "", "High", tomorrow())
        suggestion = ai.suggest_next_task()
        assert suggestion is not None
        assert suggestion.task_id == t_high.task_id

    def test_ties_broken_by_created_at(self, manager, ai):
        # Two tasks with identical priority and deadline
        t1 = manager.add_task("First", "", "Medium", in_days(10))
        t2 = manager.add_task("Second", "", "Medium", in_days(10))
        suggestion = ai.suggest_next_task()
        # t1 was created first (earlier created_at), so it wins the tie
        assert suggestion.task_id == t1.task_id

    def test_single_pending_task_is_suggested(self, manager, ai):
        t = manager.add_task("Only One", "", "Medium", tomorrow())
        assert ai.suggest_next_task().task_id == t.task_id


# ---------------------------------------------------------------------------
# get_deadline_warnings
# ---------------------------------------------------------------------------

class TestDeadlineWarnings:
    def test_no_warnings_when_all_far(self, manager, ai):
        manager.add_task("Far", "", "Low", in_days(10))
        assert ai.get_deadline_warnings() == []

    def test_task_due_today_is_warning(self, manager, ai):
        t = manager.add_task("Today", "", "High", date.today())
        warnings = ai.get_deadline_warnings()
        assert any(w.task_id == t.task_id for w in warnings)

    def test_task_due_tomorrow_is_warning(self, manager, ai):
        t = manager.add_task("Tomorrow", "", "Medium", tomorrow())
        warnings = ai.get_deadline_warnings()
        assert any(w.task_id == t.task_id for w in warnings)

    def test_completed_task_not_in_warnings(self, manager, ai):
        t = manager.add_task("Done", "", "High", date.today())
        manager.complete_task(t.task_id)
        assert ai.get_deadline_warnings() == []


# ---------------------------------------------------------------------------
# get_overdue_tasks
# ---------------------------------------------------------------------------

class TestOverdueTasks:
    def test_no_overdue_tasks(self, manager, ai):
        manager.add_task("Future", "", "Low", tomorrow())
        assert ai.get_overdue_tasks() == []

    def test_overdue_task_detected(self, manager, ai):
        t = manager.add_task("Past", "", "High", tomorrow())
        # Simulate an overdue task by directly modifying the deadline
        t.deadline = date.today() - timedelta(days=1)
        manager._save()
        overdue = ai.get_overdue_tasks()
        assert any(o.task_id == t.task_id for o in overdue)

    def test_completed_overdue_not_included(self, manager, ai):
        t = manager.add_task("Past Done", "", "High", tomorrow())
        t.deadline = date.today() - timedelta(days=1)
        manager.complete_task(t.task_id)
        assert ai.get_overdue_tasks() == []


# ---------------------------------------------------------------------------
# generate_tip
# ---------------------------------------------------------------------------

class TestGenerateTip:
    def test_no_tasks_returns_welcome(self, manager, ai, stats):
        tip = ai.generate_tip(stats)
        assert "Welcome" in tip or "first task" in tip.lower()

    def test_all_done_returns_congratulation(self, manager, ai, stats):
        t = manager.add_task("T", "", "Low", tomorrow())
        manager.complete_task(t.task_id)
        tip = ai.generate_tip(stats)
        assert "All tasks" in tip or "completed" in tip.lower() or "break" in tip.lower()

    def test_overdue_tasks_tip(self, manager, ai, stats):
        t = manager.add_task("Overdue", "", "High", tomorrow())
        t.deadline = date.today() - timedelta(days=1)
        manager._save()
        tip = ai.generate_tip(stats)
        assert "overdue" in tip.lower()

    def test_deadline_warning_tip(self, manager, ai, stats):
        manager.add_task("Soon", "", "High", date.today())
        tip = ai.generate_tip(stats)
        # Either deadline alert or overdue tip fires
        assert "deadline" in tip.lower() or "due" in tip.lower() or "overdue" in tip.lower()

    def test_many_pending_tasks_tip(self, manager, ai, stats):
        for i in range(6):
            manager.add_task(f"Task {i}", "", "Low", in_days(10))
        tip = ai.generate_tip(stats)
        assert "pending" in tip.lower() or "tasks" in tip.lower()

    def test_good_progress_tip(self, manager, ai, stats):
        tasks = []
        for i in range(10):
            t = manager.add_task(f"Task {i}", "", "Low", in_days(10))
            tasks.append(t)
        for t in tasks[:8]:
            manager.complete_task(t.task_id)
        tip = ai.generate_tip(stats)
        assert "%" in tip or "progress" in tip.lower() or "excellent" in tip.lower()
