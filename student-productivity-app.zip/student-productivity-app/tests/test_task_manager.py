"""
tests/test_task_manager.py
--------------------------
Unit tests for the Task class and TaskManager.

We use pytest's tmp_path fixture to give each test its own temporary
JSON file so tests never touch the real tasks.json.
"""

import pytest
from datetime import date, timedelta

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from task_manager import Task, TaskManager, VALID_PRIORITIES
from data_store import DataStore
from exceptions import TaskNotFoundError, TaskAlreadyCompletedError


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def store(tmp_path):
    """Return a DataStore backed by a temporary file."""
    return DataStore(file_path=str(tmp_path / "tasks.json"))


@pytest.fixture
def manager(store):
    """Return a TaskManager that uses the temporary DataStore."""
    return TaskManager(store=store)


def tomorrow() -> date:
    return date.today() + timedelta(days=1)


def yesterday() -> date:
    return date.today() - timedelta(days=1)


# ---------------------------------------------------------------------------
# Task.to_dict / from_dict
# ---------------------------------------------------------------------------

class TestTaskSerialisation:
    def test_to_dict_contains_all_keys(self, manager):
        task = manager.add_task("Test", "Desc", "High", tomorrow())
        d = task.to_dict()
        for key in [
            "task_id", "title", "description", "priority", "deadline",
            "is_completed", "created_at", "completed_at",
            "time_spent_seconds", "timer_started_at"
        ]:
            assert key in d

    def test_round_trip(self, manager):
        task = manager.add_task("Round Trip", "Test desc", "Medium", tomorrow())
        restored = Task.from_dict(task.to_dict())
        assert restored.task_id == task.task_id
        assert restored.title == task.title
        assert restored.priority == task.priority
        assert restored.deadline == task.deadline


# ---------------------------------------------------------------------------
# TaskManager.add_task
# ---------------------------------------------------------------------------

class TestAddTask:
    def test_add_valid_task(self, manager):
        task = manager.add_task("Study Python", "Chapter 1", "High", tomorrow())
        assert task.title == "Study Python"
        assert task.priority == "High"
        assert not task.is_completed

    def test_add_task_strips_whitespace_from_title(self, manager):
        task = manager.add_task("  Trimmed  ", "", "Low", tomorrow())
        assert task.title == "Trimmed"

    def test_add_task_empty_title_raises(self, manager):
        with pytest.raises(ValueError, match="empty"):
            manager.add_task("", "desc", "High", tomorrow())

    def test_add_task_whitespace_only_title_raises(self, manager):
        with pytest.raises(ValueError, match="empty"):
            manager.add_task("   ", "desc", "High", tomorrow())

    def test_add_task_title_too_long_raises(self, manager):
        long_title = "x" * 101
        with pytest.raises(ValueError, match="100"):
            manager.add_task(long_title, "desc", "High", tomorrow())

    def test_add_task_description_too_long_raises(self, manager):
        long_desc = "d" * 501
        with pytest.raises(ValueError, match="500"):
            manager.add_task("Title", long_desc, "High", tomorrow())

    def test_add_task_invalid_priority_raises(self, manager):
        with pytest.raises(ValueError, match="Priority"):
            manager.add_task("Title", "desc", "Critical", tomorrow())

    def test_add_task_past_deadline_raises(self, manager):
        with pytest.raises(ValueError, match="past"):
            manager.add_task("Title", "desc", "High", yesterday())

    def test_add_task_today_deadline_is_valid(self, manager):
        task = manager.add_task("Today Task", "", "Low", date.today())
        assert task.deadline == date.today()

    def test_add_task_persists_to_store(self, store, manager):
        manager.add_task("Persist", "", "Medium", tomorrow())
        # Create a fresh manager from the same store
        manager2 = TaskManager(store=store)
        assert len(manager2.get_all_tasks()) == 1
        assert manager2.get_all_tasks()[0].title == "Persist"

    def test_add_multiple_tasks(self, manager):
        manager.add_task("T1", "", "Low", tomorrow())
        manager.add_task("T2", "", "Medium", tomorrow())
        assert len(manager.get_all_tasks()) == 2


# ---------------------------------------------------------------------------
# TaskManager.complete_task
# ---------------------------------------------------------------------------

class TestCompleteTask:
    def test_complete_pending_task(self, manager):
        task = manager.add_task("T", "", "Low", tomorrow())
        manager.complete_task(task.task_id)
        updated = manager.get_task_by_id(task.task_id)
        assert updated.is_completed
        assert updated.completed_at is not None

    def test_complete_already_completed_raises(self, manager):
        task = manager.add_task("T", "", "Low", tomorrow())
        manager.complete_task(task.task_id)
        with pytest.raises(TaskAlreadyCompletedError):
            manager.complete_task(task.task_id)

    def test_complete_unknown_id_raises(self, manager):
        with pytest.raises(TaskNotFoundError):
            manager.complete_task("nonexistent-id")


# ---------------------------------------------------------------------------
# TaskManager.edit_task
# ---------------------------------------------------------------------------

class TestEditTask:
    def test_edit_pending_task(self, manager):
        task = manager.add_task("Old Title", "", "Low", tomorrow())
        manager.edit_task(task.task_id, "New Title", "New Desc", "High", tomorrow())
        updated = manager.get_task_by_id(task.task_id)
        assert updated.title == "New Title"
        assert updated.description == "New Desc"
        assert updated.priority == "High"

    def test_edit_completed_task_raises(self, manager):
        task = manager.add_task("T", "", "Low", tomorrow())
        manager.complete_task(task.task_id)
        with pytest.raises(TaskAlreadyCompletedError):
            manager.edit_task(task.task_id, "New", "", "Low", tomorrow())

    def test_edit_unknown_id_raises(self, manager):
        with pytest.raises(TaskNotFoundError):
            manager.edit_task("bad-id", "T", "", "Low", tomorrow())

    def test_edit_invalid_title_raises(self, manager):
        task = manager.add_task("T", "", "Low", tomorrow())
        with pytest.raises(ValueError):
            manager.edit_task(task.task_id, "", "", "Low", tomorrow())

    def test_edit_preserves_time_spent(self, manager):
        task = manager.add_task("T", "", "Low", tomorrow())
        task.time_spent_seconds = 300  # simulate time logged
        manager._save()
        manager.edit_task(task.task_id, "New Title", "", "Medium", tomorrow())
        updated = manager.get_task_by_id(task.task_id)
        assert updated.time_spent_seconds == 300


# ---------------------------------------------------------------------------
# TaskManager.delete_task
# ---------------------------------------------------------------------------

class TestDeleteTask:
    def test_delete_existing_task(self, manager):
        task = manager.add_task("Delete Me", "", "Low", tomorrow())
        manager.delete_task(task.task_id)
        assert len(manager.get_all_tasks()) == 0

    def test_delete_nonexistent_task_raises(self, manager):
        with pytest.raises(TaskNotFoundError):
            manager.delete_task("fake-id")

    def test_delete_completed_task_is_allowed(self, manager):
        task = manager.add_task("T", "", "Low", tomorrow())
        manager.complete_task(task.task_id)
        manager.delete_task(task.task_id)
        assert len(manager.get_all_tasks()) == 0


# ---------------------------------------------------------------------------
# TaskManager query methods
# ---------------------------------------------------------------------------

class TestQueryMethods:
    def test_get_pending_tasks(self, manager):
        t1 = manager.add_task("P1", "", "Low", tomorrow())
        t2 = manager.add_task("P2", "", "High", tomorrow())
        manager.complete_task(t1.task_id)
        pending = manager.get_pending_tasks()
        assert len(pending) == 1
        assert pending[0].task_id == t2.task_id

    def test_get_completed_tasks(self, manager):
        t1 = manager.add_task("C1", "", "Low", tomorrow())
        manager.complete_task(t1.task_id)
        manager.add_task("P1", "", "High", tomorrow())
        completed = manager.get_completed_tasks()
        assert len(completed) == 1

    def test_get_task_by_id_found(self, manager):
        task = manager.add_task("Find Me", "", "Medium", tomorrow())
        found = manager.get_task_by_id(task.task_id)
        assert found.title == "Find Me"

    def test_get_task_by_id_not_found(self, manager):
        with pytest.raises(TaskNotFoundError):
            manager.get_task_by_id("does-not-exist")
