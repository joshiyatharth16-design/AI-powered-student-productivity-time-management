"""
task_manager.py
---------------
Contains:
  - Task        : the data model for a single task
  - TaskManager : manages the task list (add, edit, delete, complete, query)

This module is the core of the application.
All input validation lives here — the UI never validates directly.
"""

import uuid
from datetime import date, datetime
from typing import Optional

from data_store import DataStore
from exceptions import TaskAlreadyCompletedError, TaskNotFoundError

# The only valid priority values
VALID_PRIORITIES: list[str] = ["Low", "Medium", "High"]


# ---------------------------------------------------------------------------
# Task — data model
# ---------------------------------------------------------------------------

class Task:
    """
    Represents a single student task.

    Attributes:
        task_id           : Unique identifier (UUID string), auto-generated.
        title             : Short name of the task (required).
        description       : Optional longer description.
        priority          : "Low", "Medium", or "High".
        deadline          : The due date for the task.
        is_completed      : True if the student has finished the task.
        created_at        : When the task was first created.
        completed_at      : When the task was marked complete (or None).
        time_spent_seconds: Total seconds the timer has been running for this task.
        timer_started_at  : When the timer was last started (None if not running).
                            Stored in JSON so the timer survives page refreshes.
    """

    def __init__(
        self,
        title: str,
        description: str,
        priority: str,
        deadline: date,
        task_id: Optional[str] = None,
        is_completed: bool = False,
        created_at: Optional[datetime] = None,
        completed_at: Optional[datetime] = None,
        time_spent_seconds: int = 0,
        timer_started_at: Optional[datetime] = None,
    ) -> None:
        self.task_id: str = task_id or str(uuid.uuid4())
        self.title: str = title
        self.description: str = description
        self.priority: str = priority
        self.deadline: date = deadline
        self.is_completed: bool = is_completed
        self.created_at: datetime = created_at or datetime.now()
        self.completed_at: Optional[datetime] = completed_at
        self.time_spent_seconds: int = time_spent_seconds
        self.timer_started_at: Optional[datetime] = timer_started_at

    # ------------------------------------------------------------------
    # Serialisation helpers
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Convert this Task to a plain dictionary for JSON storage."""
        return {
            "task_id": self.task_id,
            "title": self.title,
            "description": self.description,
            "priority": self.priority,
            "deadline": self.deadline.isoformat(),
            "is_completed": self.is_completed,
            "created_at": self.created_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "time_spent_seconds": self.time_spent_seconds,
            "timer_started_at": self.timer_started_at.isoformat() if self.timer_started_at else None,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Task":
        """Recreate a Task object from a dictionary loaded from JSON."""
        return cls(
            task_id=data["task_id"],
            title=data["title"],
            description=data.get("description", ""),
            priority=data["priority"],
            deadline=date.fromisoformat(data["deadline"]),
            is_completed=data.get("is_completed", False),
            created_at=datetime.fromisoformat(data["created_at"]),
            completed_at=(
                datetime.fromisoformat(data["completed_at"])
                if data.get("completed_at")
                else None
            ),
            time_spent_seconds=data.get("time_spent_seconds", 0),
            timer_started_at=(
                datetime.fromisoformat(data["timer_started_at"])
                if data.get("timer_started_at")
                else None
            ),
        )

    def __repr__(self) -> str:
        status = "Done" if self.is_completed else "Pending"
        return f"Task('{self.title}', {self.priority}, {self.deadline}, {status})"


# ---------------------------------------------------------------------------
# TaskManager — business logic layer
# ---------------------------------------------------------------------------

class TaskManager:
    """
    Manages all tasks.

    Responsibilities:
      - Load tasks from storage on startup.
      - Add, edit, delete, and complete tasks.
      - Validate all inputs before creating or updating tasks.
      - Save changes back to storage after every mutation.

    Usage:
        manager = TaskManager()
        manager.add_task("Study OS", "Read chapter 3", "High", date(2025, 6, 25))
    """

    def __init__(self, store: Optional[DataStore] = None) -> None:
        """
        Initialise the manager and load tasks from the JSON file.

        Args:
            store: A DataStore instance. Defaults to the real file-backed store.
                   Pass a custom store in tests to avoid touching tasks.json.
        """
        self._store: DataStore = store or DataStore()
        self._tasks: list[Task] = self._load_from_store()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_from_store(self) -> list[Task]:
        """Load raw dicts from storage and convert them to Task objects."""
        raw = self._store.load()
        tasks: list[Task] = []
        for item in raw:
            try:
                tasks.append(Task.from_dict(item))
            except (KeyError, ValueError):
                # Skip any corrupted records instead of crashing
                continue
        return tasks

    def _save(self) -> None:
        """Persist the current in-memory task list to storage."""
        self._store.save([t.to_dict() for t in self._tasks])

    # ------------------------------------------------------------------
    # Input validation (raises ValueError with a clear message)
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_inputs(
        title: str,
        description: str,
        priority: str,
        deadline: date,
    ) -> None:
        """
        Validate task fields.  Raises ValueError with a human-readable
        message if any field is invalid.
        """
        if not title or not title.strip():
            raise ValueError("Task title cannot be empty.")
        if len(title.strip()) > 100:
            raise ValueError("Task title must be 100 characters or fewer.")
        if len(description) > 500:
            raise ValueError("Description must be 500 characters or fewer.")
        if priority not in VALID_PRIORITIES:
            raise ValueError(
                f"Priority must be one of: {', '.join(VALID_PRIORITIES)}."
            )
        if deadline < date.today():
            raise ValueError("Deadline cannot be in the past.")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add_task(
        self,
        title: str,
        description: str,
        priority: str,
        deadline: date,
    ) -> Task:
        """
        Create a new task and save it.

        Args:
            title       : Task name (required, max 100 chars).
            description : Optional notes (max 500 chars).
            priority    : "Low", "Medium", or "High".
            deadline    : Due date; must not be in the past.

        Returns:
            The newly created Task object.

        Raises:
            ValueError: If any input is invalid.
        """
        self._validate_inputs(title.strip(), description, priority, deadline)
        task = Task(
            title=title.strip(),
            description=description.strip(),
            priority=priority,
            deadline=deadline,
        )
        self._tasks.append(task)
        self._save()
        return task

    def edit_task(
        self,
        task_id: str,
        title: str,
        description: str,
        priority: str,
        deadline: date,
    ) -> Task:
        """
        Update an existing pending task.

        Raises:
            TaskNotFoundError        : If the task_id does not exist.
            TaskAlreadyCompletedError: If the task is already completed.
            ValueError               : If any new value is invalid.
        """
        task = self.get_task_by_id(task_id)
        if task.is_completed:
            raise TaskAlreadyCompletedError(
                "Completed tasks cannot be edited."
            )
        self._validate_inputs(title.strip(), description, priority, deadline)
        task.title = title.strip()
        task.description = description.strip()
        task.priority = priority
        task.deadline = deadline
        self._save()
        return task

    def delete_task(self, task_id: str) -> None:
        """
        Remove a task from the list.

        Raises:
            TaskNotFoundError: If the task_id does not exist.
        """
        task = self.get_task_by_id(task_id)
        self._tasks.remove(task)
        self._save()

    def complete_task(self, task_id: str) -> Task:
        """
        Mark a task as completed.

        Raises:
            TaskNotFoundError        : If the task_id does not exist.
            TaskAlreadyCompletedError: If the task is already completed.
        """
        task = self.get_task_by_id(task_id)
        if task.is_completed:
            raise TaskAlreadyCompletedError(
                "This task is already marked as completed."
            )
        task.is_completed = True
        task.completed_at = datetime.now()
        self._save()
        return task

    def get_task_by_id(self, task_id: str) -> Task:
        """
        Return the task with the given ID.

        Raises:
            TaskNotFoundError: If no task has that ID.
        """
        for task in self._tasks:
            if task.task_id == task_id:
                return task
        raise TaskNotFoundError(f"No task found with ID: {task_id}")

    def get_all_tasks(self) -> list[Task]:
        """Return all tasks (pending and completed)."""
        return list(self._tasks)

    def get_pending_tasks(self) -> list[Task]:
        """Return only tasks that are not yet completed."""
        return [t for t in self._tasks if not t.is_completed]

    def get_completed_tasks(self) -> list[Task]:
        """Return only tasks that have been completed."""
        return [t for t in self._tasks if t.is_completed]
