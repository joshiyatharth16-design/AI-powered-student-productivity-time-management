# AI-Powered Student Productivity & Time Management App

A beginner-friendly Python + Streamlit application for B.Tech CSE students to manage tasks, track study time, and receive simple AI-powered productivity suggestions.

## Project Structure

```
student-productivity-app/
├── app.py                 # Streamlit UI — run this file
├── task_manager.py        # Task model + TaskManager (CRUD + validation)
├── time_tracker.py        # TimeTracker (start/stop timer)
├── statistics.py          # Statistics (completion %, daily stats)
├── ai_suggestions.py      # AISuggestion (rule-based suggestions)
├── data_store.py          # DataStore (JSON read/write)
├── exceptions.py          # Custom exceptions
├── tasks.json             # Auto-created on first run
├── requirements.txt       # Python dependencies
└── tests/
    ├── test_task_manager.py
    ├── test_time_tracker.py
    ├── test_statistics.py
    └── test_ai_suggestions.py
```

## How to Install Dependencies

```bash
pip install -r requirements.txt
```

## How to Run the Application

```bash
streamlit run app.py
```

The app will open automatically in your default browser at `http://localhost:8501`.

## How to Run Tests

```bash
pytest tests/ -v
```

## Features

- Add, edit, delete, and complete tasks
- Set priority (Low / Medium / High) and deadline
- Track time spent on each task with a start/stop timer
- View pending and completed tasks
- See daily productivity statistics
- Get AI-powered suggestions on what to work on next
